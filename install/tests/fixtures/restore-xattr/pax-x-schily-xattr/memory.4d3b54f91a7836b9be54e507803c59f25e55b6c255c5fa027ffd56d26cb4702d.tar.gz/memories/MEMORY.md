benign memory line
